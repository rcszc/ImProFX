// ext_matrixcache.
#include "ext_matrixcache.h"

using namespace std;
using namespace ExtLog;

#define MODULE_VIRTUALMEM "[virtualmem]: "
