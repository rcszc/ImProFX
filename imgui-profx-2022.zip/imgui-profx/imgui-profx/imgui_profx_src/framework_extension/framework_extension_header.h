// framework_extension_header. RCSZ 2023_12_03.

#ifndef _FRAMEWORK_EXTENSION_HEADER_H
#define _FRAMEWORK_EXTENSION_HEADER_H

#include "ext_fileloader.h" // Update:2023_12_03

#endif