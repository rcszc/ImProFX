// framework_core_loop.
#include <random>

#include "framework_core.hpp"

using namespace std;
using namespace LOGCONS;

uint32_t default_shader_hd = 0;

namespace CoreModuleIMFX {

	int32_t FrameworkImCore::ProfxEventLoop() {
		bool LogicRetFlag = false;

		RenderContextAbove(); 
		RenderGuiContextA();
		{
			RenderSceneFrameBuffer();
			ImGuiPro::FullScreenBackground(
				ImProFxTools::FrmData.FindRenderItemFBO(
					COREDATAPACK.DataShaderFx,
					"fx_background_shader"
				)
			);
			// render shader => draw background => draw imgui logic.
			for (auto it = COREDATAUSEROBJ.begin(); it != COREDATAUSEROBJ.end(); ++it)
				LogicRetFlag |= !it->second->LogicEventLoop(COREDATAPACK, COREDATAINFO);
		}
		RenderGuiContextB(); 
		RenderContextBelow();

		if (CloseFlag() || LogicRetFlag) return 0;
		else return 1;
	}

	void FrameworkImCore::RenderSceneFrameBuffer() {
		for (auto it = COREDATAPACK.DataShaderFx.begin(); it != COREDATAPACK.DataShaderFx.end(); ++it) {

			if (it->second.ExecuteProgramFlag &&
				chrono::duration_cast<chrono::microseconds>(chrono::steady_clock::now() - it->second.RenderRateTimer).count() >
				it->second.RenderRateTime
			) {
				it->second.RenderRateTimer = chrono::steady_clock::now(); // clear item timer.

				FS_FrameBufferAbove(it->second.FrameBufferHandle);
				FS_ClearFrameBuffer();

				FS_ShaderEnable(it->second.ShaderProgramHandle);
				FS_ShaderDrawMD(it->second.ModelHandle);

				// system param.
				SFglobalUniform.sUniformMat4(it->second.ShaderProgramHandle, "FxMatMvp", it->second.RenderMVPmatrix);
				SFglobalUniform.sUniform2f(it->second.ShaderProgramHandle, "FxWinSize", COREDATAINFO.WindowSize);
				SFglobalUniform.sUniform1f(it->second.ShaderProgramHandle, "FxTime", it->second.RenderTimer);

				// custom param.
				for (auto itprm = it->second.ParamValueFloat.begin(); itprm != it->second.ParamValueFloat.end(); ++itprm)
					SFglobalUniform.sUniform1f(it->second.ShaderProgramHandle, itprm->first.c_str(), itprm->second);

				for (auto& res_texture : it->second.ParamTexture)
					FS_ShaderTexture(res_texture.tmu_count, res_texture);

				FS_ShaderEnable(default_shader_hd);
				FS_FrameBufferBelow();
				FS_ClearFrameBuffer();

				it->second.RenderTimer += RENDERLOOP_TIMER_STEP * COREDATAINFO.FrameSmoothValue;
			}
		}
		// [2023_10_31] reference_fps: 60, sample_timer: 250 ms
		CalculateSmoothTrans(60.0f, 250);
		// clear unique id.
		COREDATAINFO._UniqueCountID = NULL;
		COREDATAINFO._RandomFunction = &GenerateRandomNumbers;

		// GLFW data => Framework "COREDATAINFO".
		COREDATAINFO.MousePosition = ValueMouseCursor;
		COREDATAINFO.WindowFoucs   = ValueWindowFocus;
		COREDATAINFO.DropFiles     = &FilePaths;
	}

	void FrameworkImCore::CalculateSmoothTrans(float preset_fps, int64_t sample_time) {
		if (chrono::duration_cast<chrono::milliseconds>(chrono::steady_clock::now() - SampleTimer).count() > sample_time) {
			
			TimerSmoothValue = preset_fps / (TimerSmoothCount * 1000.0f / (float)sample_time);
			TimerSmoothCount = NULL;
			SampleTimer = chrono::steady_clock::now();
		}
		TimerSmoothCount += 1.0f;
		COREDATAINFO.FrameSmoothValue += (TimerSmoothValue - COREDATAINFO.FrameSmoothValue) * 0.0072f;
	}

	float FrameworkImCore::GenerateRandomNumbers(float value_min, float value_max) {
		// device_seed => mt19937, 20231120 RCSZ.
		random_device create_random;
		mt19937 _gen(create_random());
		uniform_real_distribution<float> _dis(value_min, value_max);
		return _dis(_gen);
	}
}