// test_demo.
#include "../imgui_profx_src/improfx_core/framework_render.h"

using namespace std;
using namespace LOGCONS;

bool CoreModuleRender::FrameworkRender::LogicInitialization() {

	// Demo���� ��־:
	ImFxFind::StaticFlagAlloc(StaticFlag, "DemoWinFlag", false);

	// Demo���� & �򿪴��ڰ�ť �ؼ�:
	auto DemoWindowAnim = ImGuiProAnim::CreateAnimFixedWindow();
	auto DemoButtonAnim = ImGuiProAnim::CreateAnimButton();

	DemoWindowAnim->config_close_size = Vector2T<float>(32.0f, 32.0f);
	DemoWindowAnim->config_open_size = Vector2T<float>(1344.0f, 756.0f);

	DemoWindowAnim->config_close_color = Vector4T<float>(0.0f, 0.0f, 0.0f, 0.0f);
	DemoWindowAnim->config_open_color = Vector4T<float>(0.0f, 0.0f, 0.0f, 0.52f);

	DemoWindowAnim->config_color_transspeed = 0.25f;

	DemoButtonAnim->config_hover_size = Vector2T<float>(135.0f, 48.0f);
	DemoButtonAnim->config_active_size = Vector2T<float>(108.0f, 32.0f);

	DemoButtonAnim->config_normal_color = Vector4T<float>(0.32f, 0.0f, 1.0f, 0.48f);
	DemoButtonAnim->config_hover_color = Vector4T<float>(1.0f, 0.32f, 0.0f, 0.78f);
	DemoButtonAnim->config_active_color = Vector4T<float>(1.0f, 0.0f, 0.32f, 0.78f);

	ImGuiProAnim::AnimCompReg(DataCompAnim, "DemoWinComp", DemoWindowAnim);
	ImGuiProAnim::AnimCompReg(DataCompAnim, "DemoButComp", DemoButtonAnim);

	// Demo�����ڻ����ؼ�:
	auto SrcComp = ImGuiProAnim::CreateAnimSrcMoveColor();

	// "logo11" ���� & ��ɫ.
	SrcComp->config_low_color = Vector4T<float>();
	SrcComp->config_high_color = Vector4T<float>(1.0f, 1.0f, 1.0f, 1.0f);

	SrcComp->config_low_position = Vector2T<float>(0.0f, 480.0f);
	SrcComp->config_high_position = Vector2T<float>(0.0f, 72.0f);

	SrcComp->config_color_transspeed = 0.38f;
	SrcComp->config_position_transspeed = 0.65f;

	// ��ǩ����.
	auto SrcCompLable = ImGuiProAnim::CreateAnimSrcMoveColor(SrcComp);

	SrcCompLable->config_low_position = Vector2T<float>(0.0f, 0.0f);
	SrcCompLable->config_high_position = Vector2T<float>(0.0f, 328.0f);

	SrcCompLable->config_color_transspeed = 0.24f;
	SrcCompLable->config_position_transspeed = 0.42f;

	ImGuiProAnim::AnimCompReg(DataCompAnim, "Logo11", SrcComp);
	ImGuiProAnim::AnimCompReg(DataCompAnim, "lable", SrcCompLable);

	// ����ť.
	auto DemoMainBut = ImGuiProAnim::CreateAnimButton();

	ImGuiProAnim::AnimCompReg(DataCompAnim, "demobut", DemoMainBut);

	DemoMainBut->config_normal_size = Vector2T<float>(240.0f, 80.0f);
	DemoMainBut->config_hover_size = Vector2T<float>(250.0f, 84.0f);
	DemoMainBut->config_active_size = Vector2T<float>(220.0f, 74.0f);

	DemoMainBut->config_normal_color = Vector4T<float>(1.0f, 1.0f, 1.0f, 0.2f);
	DemoMainBut->config_hover_color = Vector4T<float>(1.0f, 1.0f, 1.0f, 0.72f);
	DemoMainBut->config_active_color = Vector4T<float>(0.0f, 1.0f, 1.0f, 0.72f);

	ImGuiProAnim::AnimCompReg(DataCompAnim, "demobut", DemoMainBut);

	// ���ֻ���.
	auto SrcCompText = ImGuiProAnim::CreateAnimSrcMoveColor();

	SrcCompText->config_low_color = Vector4T<float>();
	SrcCompText->config_high_color = Vector4T<float>(1.0f, 1.0f, 1.0f, 1.0f);

	SrcCompText->config_low_position = Vector2T<float>(0.0f, 72.0f);
	SrcCompText->config_high_position = Vector2T<float>(370.0f, 72.0f);

	ImGuiProAnim::AnimCompReg(DataCompAnim, "demotext", SrcCompText);

	// logo�ؼ��л���־.
	ImFxFind::StaticFlagAlloc(StaticFlag, "DemoLogoFlag", true);

	return true;
}

bool CoreModuleRender::FrameworkRender::LogicEventLoop() {

	auto stcflag = ImFxFind::StaticFlagFind(StaticFlag, "DemoWinFlag");
	auto logoflag = ImFxFind::StaticFlagFind(StaticFlag, "DemoLogoFlag");

	ImGui::PushStyleColor(ImGuiCol_TitleBg, ImVec4(1.0f, 0.32f, 0.0f, 0.52f));
	ImGui::PushStyleColor(ImGuiCol_TitleBgActive, ImVec4(1.0f, 0.32f, 0.0f, 0.52f));

	ImGuiPro::BeginBg(
		"MAIN PANEL",
		ImFxFind::FindRenderItemFBO(DataFxRender, "fx_circle_shader"),
		ImVec2(256.0, 384.0f),
		ImVec2(0.42f, 1.0f)
	);

	ImGui::PopStyleColor();
	ImGui::PopStyleColor();

	if (ImGuiProAnim::CallAnimButton("StartDemo", DataCompAnim, "DemoButComp"))
		*stcflag = !*stcflag;

	if (!*stcflag)
		*logoflag = true;

	ImGui::End();

	// �򿪴���ʱ��������ɫ��.
	ImFxFind::FindSetRenderItemFlag(DataFxRender, "fx_sunsky_shader", *stcflag);

	ImGui::PushStyleColor(ImGuiCol_TitleBg, ImVec4(1.0f, 0.32f, 0.0f, 0.52f));
	ImGui::PushStyleColor(ImGuiCol_TitleBgActive, ImVec4(1.0f, 0.32f, 0.0f, 0.52f));
	
	ImGuiProAnim::CallAnimFixedWindow(
		"ImProFx 1.1.0A",
		DataCompAnim,
		"DemoWinComp",
		*stcflag, [&]() {
			ImGuiPro::FullWindowBackground(
				ImFxFind::FindRenderItemFBO(DataFxRender, "fx_sunsky_shader"),
				ImVec2(0.85f, 1.0f)
			);

			ImGuiProAnim::CallAnimSrcMoveColor(DataCompAnim, "Logo11", *stcflag && *logoflag,
				[&](Vector4T<float> incolor) {

					float indentlen = ImGuiPro::ItemCenteredCalc(1024.0f);
					ImGui::Indent(indentlen);

					ImGui::Image(
						CVT_IMPTR(ImFxFind::FindRawTextureImg(DataRawTexture, "login_improfx11")),
						ImVec2(1024.0f, 256.0f),
						ImVec2(0.0f, 0.0f),
						ImVec2(1.0f, 1.0f),
						ImVec4(incolor.vector_x, incolor.vector_y, incolor.vector_z, incolor.vector_w)
					);

					ImGui::Unindent(indentlen + IMGUI_ITEM_SPC);
				}
			);

			ImGuiProAnim::CallAnimSrcMoveColor(DataCompAnim, "lable", *stcflag && *logoflag,
				[&](Vector4T<float> incolor) {

					float indentlen = ImGuiPro::ItemCenteredCalc(544.0);
					ImGui::Indent(indentlen + IMGUI_ITEM_SPC);

					ImGui::Image(
						CVT_IMPTR(ImFxFind::FindRawTextureImg(DataRawTexture, "lable_msf")),
						ImVec2(128.0f, 64.0f),
						ImVec2(0.0f, 0.0f),
						ImVec2(1.0f, 1.0f),
						ImVec4(incolor.vector_x, incolor.vector_y, incolor.vector_z, incolor.vector_w)
					);
					ImGui::SameLine();

					if (ImGui::IsItemHovered()) {
						ImGuiPro::MouseFloatingWindow(ImVec2(200.0f, 80.0f), true,
							[]() {
								ImGui::TextColored(ImVec4(1.0f, 1.0f, 1.0f, 0.85f), "Module: ShaderFx");
								ImGui::TextColored(ImVec4(1.0f, 1.0f, 1.0f, 0.85f), "Version: 1.0.0 Ahpla");
								ImGui::TextColored(ImVec4(1.0f, 1.0f, 1.0f, 0.85f), "OpenGL GLEW");
							}
						);
					}

					ImGui::Image(
						CVT_IMPTR(ImFxFind::FindRawTextureImg(DataRawTexture, "lable_mat")),
						ImVec2(128.0f, 64.0f),
						ImVec2(0.0f, 0.0f),
						ImVec2(1.0f, 1.0f),
						ImVec4(incolor.vector_x, incolor.vector_y, incolor.vector_z, incolor.vector_w)
					);
					ImGui::SameLine();

					if (ImGui::IsItemHovered()) {
						ImGuiPro::MouseFloatingWindow(ImVec2(200.0f, 80.0f), true,
							[]() {
								ImGui::TextColored(ImVec4(1.0f, 1.0f, 1.0f, 0.85f), "Module: Animation");
								ImGui::TextColored(ImVec4(1.0f, 1.0f, 1.0f, 0.85f), "Version: 1.0.0 Ahpla");
								ImGui::TextColored(ImVec4(1.0f, 1.0f, 1.0f, 0.85f), "'framework_animation'");
							}
						);
					}

					ImGui::Image(
						CVT_IMPTR(ImFxFind::FindRawTextureImg(DataRawTexture, "lable_mip")),
						ImVec2(128.0f, 64.0f),
						ImVec2(0.0f, 0.0f),
						ImVec2(1.0f, 1.0f),
						ImVec4(incolor.vector_x, incolor.vector_y, incolor.vector_z, incolor.vector_w)
					);
					ImGui::SameLine();

					if (ImGui::IsItemHovered()) {
						ImGuiPro::MouseFloatingWindow(ImVec2(200.0f, 80.0f), true,
							[]() {
								ImGui::TextColored(ImVec4(1.0f, 1.0f, 1.0f, 0.85f), "Module: ImGuiPro");
								ImGui::TextColored(ImVec4(1.0f, 1.0f, 1.0f, 0.85f), "Version: 1.0.0 Ahpla");
								ImGui::TextColored(ImVec4(1.0f, 1.0f, 1.0f, 0.85f), "ImGui OpenGL3");
							}
						);
					}

					ImGui::Image(
						CVT_IMPTR(ImFxFind::FindRawTextureImg(DataRawTexture, "lable_mem")),
						ImVec2(128.0f, 64.0f),
						ImVec2(0.0f, 0.0f),
						ImVec2(1.0f, 1.0f),
						ImVec4(incolor.vector_x, incolor.vector_y, incolor.vector_z, incolor.vector_w)
					);

					if (ImGui::IsItemHovered()) {
						ImGuiPro::MouseFloatingWindow(ImVec2(200.0f, 80.0f), true,
							[]() {
								ImGui::TextColored(ImVec4(1.0f, 1.0f, 1.0f, 0.85f), "Module: Memory");
								ImGui::TextColored(ImVec4(1.0f, 1.0f, 1.0f, 0.85f), "Version: 1.1.0 Ahpla");
								ImGui::TextColored(ImVec4(1.0f, 1.0f, 1.0f, 0.85f), "'framework_memory'");
							}
						);
					}

					ImGui::Indent(indentlen + IMGUI_ITEM_SPC * 2.0f);
				}
			);

			ImGuiProAnim::CallAnimSrcMoveColor(DataCompAnim, "demotext", !*logoflag,
				[&](Vector4T<float> incolor) {

					ImFxFind::FindSetRenderItemParam(DataFxRender, "fx_sunsky_shader", "lightning", 1.0f - incolor.vector_w);

					const char* fxtext = 
						u8">- ImGuiProFx��һ������imgui��shader����ǿ�Ӿ�Ч����GUI���. \n>- ��ǰ�汾version 1.1.0A. \n>- �����1.0.0�汾�޸���һЩ����Bug, �Լ�������һЩ�¹���. \n>- δ��1.x�汾�����ٸ����¹���, ���ܻ��޸�һЩbug. \n>- version 2.0.0A�汾Ԥ����2023���Ϧ������. \n>- 2.0�汾���и���Ŀؼ�, �Լ������ϵļ�. \n>- imgui��һ�����������ܸ����ɶȵļ�ʱGUI, ���Ӿ�Ч��&�ؼ��Ϻ��б�Ҫ��չ����. \n>- RCSZ 2023.11 v1.1";
					
					ImGui::SetWindowFontScale(1.5f);
					ImGuiPro::PushStyleColor(ImGuiCol_Text, incolor);
					ImGui::TextUnformatted(fxtext);
					ImGui::PopStyleColor();
				}
			);

			ImGui::SetCursorPos(ImVec2(ImGuiPro::ItemCenteredCalc(256.0f), 500.0f));
			if (ImGuiProAnim::CallAnimButtonImage(
				"IMPROFX",
				DataCompAnim,
				"demobut",
				ImFxFind::FindRawTextureImg(DataRawTexture, "butcircle")
			)) {
				*logoflag = !*logoflag;
			}
		},
		ImGuiWindowFlags_NoTitleBar
	);

	// ��λ.
	if (!*stcflag) {
		ImGuiProAnim::CallAnimSrcMoveColorRES(DataCompAnim, "Logo11", Vector4T<float>(), Vector2T<float>(0.0f, 420.0f));
		ImGuiProAnim::CallAnimSrcMoveColorRES(DataCompAnim, "lable", Vector4T<float>(), Vector2T<float>(0.0f, 0.0f));
	}

	ImGui::PopStyleColor();
	ImGui::PopStyleColor();

	return false;
}

void CoreModuleRender::FrameworkRender::LogicCloseFree() {

}