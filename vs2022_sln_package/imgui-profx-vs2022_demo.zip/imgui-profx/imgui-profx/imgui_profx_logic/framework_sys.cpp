// test_demo.
#include "../imgui_profx_src/improfx_core/framework_render.h"

using namespace std;
using namespace LOGCONS;

bool CoreModuleRender::FrameworkRender::LogicInitialization() {

	auto cfgcomp = ImGuiProAnim::CreateAnimButton();
	auto cfgcomp_win = ImGuiProAnim::CreateAnimFixedWindow();

	cfgcomp->config_hover_color = Vector4T<float>(0.0f, 1.0f, 1.0f, 1.0f);
	cfgcomp->config_active_color = Vector4T<float>(1.0f, 0.0f, 0.32f, 1.0f);

	cfgcomp->config_normal_size = Vector2T<float>(32.0f, 32.0f);
	cfgcomp->config_hover_size = Vector2T<float>(36.0f, 36.0f);
	cfgcomp->config_active_size = Vector2T<float>(32.0f, 32.0f);

    // "����"��ť
	ImGuiProAnim::AnimCompReg(DataCompAnim, "CompButtonSettings", cfgcomp);

	cfgcomp_win->config_close_color = Vector4T<float>();
	cfgcomp_win->config_open_color = Vector4T<float>(0.5f, 0.05f, 1.0f, 0.42f);

	cfgcomp_win->config_close_size = Vector2T<float>(0.0f, 0.0f);
	cfgcomp_win->config_open_size = Vector2T<float>(512.0f, 256.0f);

	cfgcomp_win->config_color_transspeed = 0.5f;

	// "����"����
	ImGuiProAnim::AnimCompReg(DataCompAnim, "CompWindowSettings", cfgcomp_win);

	cfgcomp = ImGuiProAnim::CreateAnimButton();

	cfgcomp->config_hover_color = Vector4T<float>(0.0f, 1.0f, 1.0f, 1.0f);
	cfgcomp->config_active_color = Vector4T<float>(1.0f, 0.0f, 0.32f, 1.0f);

	cfgcomp->config_active_size = Vector2T<float>(100.0f, 30.0f);

	// "���˵�"��ť
	ImGuiProAnim::AnimCompReg(DataCompAnim, "CompButtonMenu1", cfgcomp);

	// �������ô��� "CompButtonMenu1" - "CompButtonMenu4"
	cfgcomp = ImGuiProAnim::CreateAnimButton(cfgcomp);
	ImGuiProAnim::AnimCompReg(DataCompAnim, "CompButtonMenu2", cfgcomp);

	cfgcomp = ImGuiProAnim::CreateAnimButton(cfgcomp);
	ImGuiProAnim::AnimCompReg(DataCompAnim, "CompButtonMenu3", cfgcomp);

	cfgcomp = ImGuiProAnim::CreateAnimButton(cfgcomp);
	ImGuiProAnim::AnimCompReg(DataCompAnim, "CompButtonMenu4", cfgcomp);

	// "Demo��¼"���ڰ�ť
	cfgcomp = ImGuiProAnim::CreateAnimButton(cfgcomp);

	cfgcomp->config_hover_color = Vector4T<float>(0.48f, 0.05f, 1.0f, 1.0f);
	cfgcomp->config_active_color = Vector4T<float>(1.0f, 0.0f, 0.32f, 1.0f);

	cfgcomp->config_normal_size = Vector2T<float>(200.0f, 100.0f);
	cfgcomp->config_hover_size = Vector2T<float>(200.0f, 100.0f);
	cfgcomp->config_active_size = Vector2T<float>(160.0f, 80.0f);

	ImGuiProAnim::AnimCompReg(DataCompAnim, "CompButtonDemoLogin", cfgcomp);

	cfgcomp_win = ImGuiProAnim::CreateAnimFixedWindow();

	cfgcomp_win->config_close_size = Vector2T<float>(0.0f, 0.0f);
	cfgcomp_win->config_open_size = Vector2T<float>(896.0f, 512.0f);

	// "Login"����
	ImGuiProAnim::AnimCompReg(DataCompAnim, "CompWindowDemoLogin", cfgcomp_win);

	// "Demo���״̬"���ڰ�ť
	cfgcomp = ImGuiProAnim::CreateAnimButton();

	cfgcomp->config_hover_color = Vector4T<float>(0.48f, 0.05f, 1.0f, 1.0f);
	cfgcomp->config_active_color = Vector4T<float>(1.0f, 0.0f, 0.32f, 1.0f);

	cfgcomp->config_normal_size = Vector2T<float>(120.0f, 40.0f);
	cfgcomp->config_hover_size = Vector2T<float>(140.0f, 50.0f);
	cfgcomp->config_active_size = Vector2T<float>(120.0f, 40.0f);

	ImGuiProAnim::AnimCompReg(DataCompAnim, "CompButtonDemoState", cfgcomp);

	cfgcomp_win = ImGuiProAnim::CreateAnimFixedWindow(cfgcomp_win);

	cfgcomp_win->config_close_color = Vector4T<float>();
	cfgcomp_win->config_open_color = Vector4T<float>(0.5f, 0.05f, 1.0f, 0.42f);

	cfgcomp_win->config_close_size = Vector2T<float>(0.0f, 0.0f);
	cfgcomp_win->config_open_size = Vector2T<float>(512.0f, 320.0f);

	// "FrameState"����
	ImGuiProAnim::AnimCompReg(DataCompAnim, "CompWindowDemoState", cfgcomp_win);

	return true;
}

bool CoreModuleRender::FrameworkRender::LogicEventLoop() {

	ImGui::PushStyleColor(ImGuiCol_TitleBg, ImVec4(0.24f, 0.0f, 0.58f, 0.8f));
	ImGui::PushStyleColor(ImGuiCol_TitleBgActive, ImVec4(0.24f, 0.0f, 0.58f, 0.8f));
	ImGui::PushStyleColor(ImGuiCol_TitleBgCollapsed, ImVec4(0.24f, 0.0f, 0.58f, 0.8f));

	ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 1.0f, 1.0f, 0.72f));

	ImGuiPro::BeginBg(
		"ImProFx Demo [v1.0.0]", 
		ImFxFind::FindRenderItemFBO(DataFxRender, "fx_starsky_shader"), 
		ImVec2(360.0f, 720.0f), 
		ImVec2(0.28125f, 1.0f),
		(bool*)0,
		ImGuiWindowFlags_NoCollapse
	);

	ImGui::PopStyleColor();

	ImGui::PopStyleColor();
	ImGui::PopStyleColor();
	ImGui::PopStyleColor();

	ImGuiPro::TextCentered("IMGUI PRO FX - I", ImVec4(0.0f, 1.0f, 1.0f, 1.0f));

	ImGui::SetCursorPos(ImVec2(ImGui::GetWindowWidth() - 35.0f - IMGUI_ITEM_SPC * 2.0f, IMGUI_ITEM_SPC * 4.0f));

	static bool settings_winflag = false;
	if (ImGuiProAnim::CallAnimButtonImage("SET", DataCompAnim, "CompButtonSettings", ImFxFind::FindRawTextureImg(DataRawTexture, "icon_settings")))
		settings_winflag = !settings_winflag;

	ImGuiPro::EndEnterLine();
	
	ImGuiProAnim::CallAnimFixedWindow("Settings", DataCompAnim, "CompWindowSettings", settings_winflag,
		[&]() {

			static float bg_param_speed = 1.0f, bg_param_bright = 1.0f;
			static bool shader_sw[2] = { true,true };

			ImGui::SliderFloat("Background Speed", &bg_param_speed, -2.0f, 2.0f);
			ImFxFind::FindSetRenderItemParam(DataFxRender, "fx_background_shader", "space_speed", bg_param_speed);

			ImGui::SliderFloat("Background Bright", &bg_param_bright, 0.0f, 2.0f);
			ImFxFind::FindSetRenderItemParam(DataFxRender, "fx_background_shader", "space_brightness", bg_param_bright);

			ImGui::Checkbox("Background shader run", &shader_sw[0]);
			ImFxFind::FindSetRenderItemFlag(DataFxRender, "fx_background_shader", shader_sw[0]);

			ImGui::Checkbox("MainWindow shader run", &shader_sw[1]);
			ImFxFind::FindSetRenderItemFlag(DataFxRender, "fx_starsky_shader", shader_sw[1]);
		}
	);

	ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 0.24f, 0.0f, 1.0f));

	ImGuiProAnim::CallAnimButton("Button A", DataCompAnim, "CompButtonMenu1");
	if (ImGui::IsItemHovered()) ImGuiPro::MouseFloatingWindow(ImVec2(256.0f, 32.0f), true, []() { ImGui::Text("Animation Button DemoA."); });

	ImGui::SameLine();

	ImGuiProAnim::CallAnimButton("Button B", DataCompAnim, "CompButtonMenu2");
	if (ImGui::IsItemHovered()) ImGuiPro::MouseFloatingWindow(ImVec2(256.0f, 32.0f), true, []() { ImGui::Text("Animation Button DemoB."); });

	ImGuiProAnim::CallAnimButton("Button C", DataCompAnim, "CompButtonMenu3");
	if (ImGui::IsItemHovered()) ImGuiPro::MouseFloatingWindow(ImVec2(256.0f, 32.0f), true, []() { ImGui::Text("Animation Button DemoC."); });

	ImGui::SameLine();

	ImGuiProAnim::CallAnimButton("Button D", DataCompAnim, "CompButtonMenu4");
	if (ImGui::IsItemHovered()) ImGuiPro::MouseFloatingWindow(ImVec2(256.0f, 32.0f), true, []() { ImGui::Text("Animation Button DemoD."); });

	ImGui::PopStyleColor();

	ImGui::Text("");
	ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "Demo: Animation Button");
	ImGuiPro::EndEnterLine();

	static bool login_winflag = false;
	if (ImGuiProAnim::CallAnimButtonImage("LOGIN", DataCompAnim, "CompButtonDemoLogin", ImFxFind::FindRawTextureImg(DataRawTexture, "pomelo_logo")))
		login_winflag = !login_winflag;

	// �򿪴���ʱ shader �ſ�ʼ����.
	ImFxFind::FindSetRenderItemFlag(DataFxRender, "fx_circle_shader", login_winflag);

	ImGuiProAnim::CallAnimFixedWindow("Login", DataCompAnim, "CompWindowDemoLogin", login_winflag,
		[&]() {
			ImGuiPro::FullWindowBackground(ImFxFind::FindRenderItemFBO(DataFxRender, "fx_circle_shader"));

			ImGui::Image(CVT_IMPTR(ImFxFind::FindRawTextureImg(DataRawTexture, "login_improfx")), ImVec2(890.0f, 258.0f));

			static char password_buffer[16] = {};
			static char account_buffer[32] = {};

			static bool account_flag = false, password_flag = true;

			ImGuiPro::InputTextCentered("Account", account_buffer, 32, 200.0f, account_flag, 0);
			ImGuiPro::InputTextCentered("Password", password_buffer, 16, 200.0f, password_flag, 1);

			ImGui::Text("");

			ImGui::SetCursorPosX(ImGuiPro::ItemCenteredCalc(240.0f));
			ImGuiPro::ButtonImageText(
				"LOGIN IMPROFX",
				ImFxFind::FindRenderItemFBO(DataFxRender, "fx_artcoding_shader"),
				ImVec2(240.0f, 60.0f),
				0,
				ImVec2(1.0f, 0.42f)
			);
		}
	);

	ImGui::Text("");
	ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "Demo: Login");
	ImGuiPro::EndEnterLine();

	ImGuiPro::AnalogLED(true);  ImGui::SameLine();
	ImGuiPro::AnalogLED(true);  ImGui::SameLine();
	ImGuiPro::AnalogLED(false); ImGui::SameLine();
	ImGuiPro::AnalogLED(false); ImGui::SameLine();
	ImGuiPro::AnalogLED(true);  ImGui::SameLine();
	ImGuiPro::AnalogLED(false); ImGui::SameLine();
	ImGuiPro::AnalogLED(true);

	static bool state_winflag = false;
	if (ImGuiProAnim::CallAnimButton("STATE", DataCompAnim, "CompButtonDemoState"))
		state_winflag = !state_winflag;

	ImGuiProAnim::CallAnimFixedWindow("FrameworkState", DataCompAnim, "CompWindowDemoState", state_winflag,
		[&]() {
			
			ImGui::Text("Framework ImGui Fps: %0.3f", ImGui::GetIO().Framerate);
			ImGui::Text("Framework ImGui MousePos: [%0.1f, %0.1f]", ImGui::GetIO().MousePos.x, ImGui::GetIO().MousePos.y);
			ImGui::Text("Framework Tick Smooth: %0.3f", TimerSmoothValue[1]);

			ImGui::Text("");
			ImGui::Text("Framework timer: 'fx_background_shader': %0.2f", ImFxFind::FindRenderItem(DataFxRender, "fx_background_shader").RenderTimer);
			ImGui::Text("Framework timer: 'fx_starsky_shader': %0.2f", ImFxFind::FindRenderItem(DataFxRender, "fx_starsky_shader").RenderTimer);
			ImGui::Text("Framework timer: 'fx_artcoding_shader': %0.2f", ImFxFind::FindRenderItem(DataFxRender, "fx_artcoding_shader").RenderTimer);
			ImGui::Text("Framework timer: 'fx_circle_shader': %0.2f", ImFxFind::FindRenderItem(DataFxRender, "fx_circle_shader").RenderTimer);
			
			ImGui::Text("");
			ImGui::Text("Framework data: 'DataFxRender': %d", DataFxRender.size());
			ImGui::Text("Framework data: 'DataRawTexture': %d", DataRawTexture.size());
			ImGui::Text("Framework data: 'DataCompAnim': %d", DataCompAnim.size());
		}
	);

	ImGui::Text("");
	ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "Demo: Framework State");
	ImGuiPro::EndEnterLine();
	
	ImGui::End();

	return false;
}

void CoreModuleRender::FrameworkRender::LogicCloseFree() {

}