// test_demo.
#include "../imgui_profx_src/improfx_core/framework_render.h"

using namespace std;
using namespace LOGCONS;

bool CoreModuleRender::FrameworkRender::LogicInitialization() {

	

	return true;
}

bool CoreModuleRender::FrameworkRender::LogicEventLoop() {

	

	return false;
}

void CoreModuleRender::FrameworkRender::LogicCloseFree() {

}