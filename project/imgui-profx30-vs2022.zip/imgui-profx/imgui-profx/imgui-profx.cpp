﻿/* 
* Project [StartTime]: 2023.10.12
* ImGuiProFX - III, Version 3.0.0 TEST @RCSZ 2024 - 2025.
* Libray: OpenGL GLFW, OpenGL GLEW, ImGui, RapidJSON, stb_image, stb_image_write.
* Msvc C++17 Release x64, IDE: Visual Studio 2022.
* --------------------------------------------------------
* 基于ImGui和OpenGL着色器的GUI框架, 为提升原版ImGui的视角效果以及体验.
* 为开发者提供更多工具, 保留ImGui的即时性和简洁. (20231012)
* --------------------------------------------------------
* ImProFX框架将不再是纯粹的GUI开发框架, 将更聚焦于特效的开发、学习、制作和渲染.
* 这项改革并不违背"ProFX"反而更加突出"FX".
* 这也将极度简化文档, GUI动画等只作为框架开发, 框架使用只有特效部分. (20240126)
*/

#include <iostream>
#include "imgui_profx_src/improfx_core/framework_core.hpp"

using namespace std;

#pragma warning(disable: 4819) // (无丝竹之乱耳

int main() {
	//LOGCONS::SET_PRINTLOG_STAT(false); // 关闭控制台输出日志.
	
	CoreModuleIMFX::FrameworkImCore* ImProFxFramework = new CoreModuleIMFX::FrameworkImCore();
	IMFX_SYSTEM_OBJ.FrameworkRegStart(ImProFxFramework);

	return IMFX_SYSTEM_OBJ.StartProfx();
}